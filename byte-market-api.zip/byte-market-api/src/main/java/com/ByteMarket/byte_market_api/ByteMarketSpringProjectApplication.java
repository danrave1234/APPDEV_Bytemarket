package com.ByteMarket.byte_market_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ByteMarketSpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ByteMarketSpringProjectApplication.class, args);
	}

}
