package com.ByteMarket.byte_market_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ByteMarketSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
